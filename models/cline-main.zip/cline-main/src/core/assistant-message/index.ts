import { ClineDefaultTool } from "@shared/tools"

export type AssistantMessageContent = TextStreamContent | ToolUse | ReasoningStreamContent

export { parseAssistantMessageV2 } from "./parse-assistant-message"

export interface TextStreamContent {
	type: "text"
	content: string
	partial: boolean
}

export const toolParamNames = [
	"command",
	"requires_approval",
	"path",
	"absolutePath",
	"content",
	"diff",
	"regex",
	"file_pattern",
	"recursive",
	"action",
	"url",
	"coordinate",
	"text",
	"server_name",
	"tool_name",
	"arguments",
	"uri",
	"question",
	"options",
	"response",
	"result",
	"context",
	"title",
	"what_happened",
	"steps_to_reproduce",
	"api_request_output",
	"additional_context",
	"needs_more_exploration",
	"task_progress",
	"timeout",
	"input",
] as const

export type ToolParamName = (typeof toolParamNames)[number]

export interface ToolUse {
	type: "tool_use"
	name: ClineDefaultTool // id of the tool being used
	// params is a partial record, allowing only some or none of the possible parameters to be used
	params: Partial<Record<ToolParamName, string>>
	partial: boolean
	// Whether this tool use was initiated by a native tool call
	isNativeToolCall?: boolean
}

export interface ReasoningStreamContent {
	type: "reasoning"
	reasoning: string
	details?: any // openrouter has various properties that we can pass back unmodified in api requests to preserve reasoning traces
	signature?: string
	redacted?: boolean // whether this reasoning block has been redacted
	data?: string // redacted data
	partial: boolean
}
